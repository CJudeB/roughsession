drop database if exists collection;
create database collection;
use collection;

create table artefact
(
    artefact_id serial primary key,
    membername text,
    title text,
    type text,
    description text,
    year year,
    price int,
    imagename text
);

create table member
(
    user_id serial primary key,
    membername varchar(20),
    password char(40),
    reg_date datetime
);