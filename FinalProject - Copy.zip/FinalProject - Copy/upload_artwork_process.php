<?php
// var_dump($_FILES); image file upload debug
var_dump($_SESSION['membername']);

session_start();

$title = "Upload Artwork";
include('includes/header.inc');

function validate_input($str)
{
    $str = trim($str);
    $str = stripslashes($str);
    $str = htmlspecialchars($str);
    return $str;
}

//if (isset($_POST['upload'])) {
    $artefact_id = validate_input($_POST['artefact_id']);
    $membername = validate_input($_SESSION['membername']);
    $title = validate_input($_POST['title']);
    $type = validate_input($_POST['type']);
    $description = validate_input($_POST['description']);
    $year = validate_input($_POST['year']);
    $price = validate_input($_POST['price']);
    $imagename = validate_input($_FILES['artwork']['name']);

    include('includes/db_connect.inc');

    $sql = "INSERT INTO artefact (`artefact_id`, `membername`, `title`, `type`, `description`, `year`, `price`,`imagename`) VALUES (?,?,?,?,?,?,?,?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("issssbis", $artefact_id, $membername, $title, $type, $description, $year, $price, $imagename);

    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        if (!empty($_FILES['artwork'])) {
            $tmp = $_FILES['artwork']['tmp_name'];
            $dest = "images/{$_FILES['artwork']['name']}";
            move_uploaded_file($tmp, $dest);
        }
        echo "A new artwork has been added";
        header("Location:index.php");
        exit(0);
    } else {
        echo "An error has occured!";
    }

    $conn->close();
//}

include('includes/footer.inc'); 
