<?php
$title = "Logout";
include("includes/header.inc");
session_unset();
session_destroy();

include("includes/nav.inc");
?>

<h2>Adiós</h2>
<p>You have successfully logged out.</p>

<?php
include("includes/footer.inc");
?>