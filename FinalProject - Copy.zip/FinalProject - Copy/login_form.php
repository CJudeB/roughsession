<?php
$title = "Login";
include('includes/header.inc');
?>

<?php
include('includes/nav.inc');
?>
<!--
<div class="container-fluid bg-light">
        <h2 class="text-center text-dark p-1"><br>Member Login<br></h2>
        <div class="form-group">
        <div class="row justify-content-center">
        <form action="login_process.php" method="post">
            <label for="membername"><br>Membername<br></label>
            <input type="text" name="membername" id="membername"><br><br>
            <label for="password">Password</label>
            <input type="password" name="password" id="password"><br><br>
            <input type="submit" value="Login">
        </form>
        </div>
    </div>
</div>
-->
<div class="container bg-light">
    <h2><br>Member Login</h2>
    <form action="login_process.php" method="post">
        <div class="form-group">
            <label for="membername">Membername</label>
            <input type="text" class="form-control" id="membername" placeholder="membername" name="membername">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" placeholder="password" name="password">
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
</div>

</body>

</html>
<?php
include('includes/footer.inc');
?>