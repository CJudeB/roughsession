<?php
$title = "Registration";
include('includes/header.inc');
?>

<?php
include('includes/nav.inc');
?>
<!--<div>
    <h2>Member Registration</h2>
    <form action="registration_process.php" method="post">
    <label for="membername">Membername</label>
    <input type="text" name="membername" id="membername" required><br><br>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" required><br><br>
    <input type="submit" value="Register">
</form>
</div>
<?php
//include('includes/footer.inc');
?>-->

<div class="container bg-light">
    <h2><br>Member Registration</h2>
    <form action="registration_process.php" method="post">
        <div class="form-group">
            <label for="membername">Membername</label>
            <input type="text" class="form-control" id="membername" placeholder="membername" name="membername" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" placeholder="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>
<?php
include('includes/footer.inc');
?>
