<?php
include('includes/header.inc');
?>
<div class="container-fluid p-5 my-5 bg-dark text-white">
<h1 class="text-center pb-2">Collection Artefacts</h1>
</div>
<?php
include('includes/nav.inc');
?>
<h4>About Artefacts Collection</h4>

<p>Donec sagittis magna vel euismod ornare. Aenean a diam finibus, euismod lorem et, fermentum dolor. Morbi ac finibus turpis. Morbi purus nisi, vehicula a luctus nec, accumsan id nulla. Vivamus nec tristique diam. Maecenas tincidunt congue orci, eleifend faucibus velit fringilla et. Ut id lorem luctus enim scelerisque elementum vitae nec risus. Curabitur consectetur varius consectetur. Duis vitae nibh euismod, imperdiet ante ac, convallis turpis. Vestibulum dictum quam vitae orci placerat ornare. Nunc ultricies commodo purus, eu blandit lacus sagittis sit amet. Fusce cursus, lectus eget facilisis viverra, nunc felis interdum magna, quis condimentum neque dolor non orci.</p>
<?php
include('includes/footer.inc');
?>