<?php
$title = "";
include('includes/header.inc');
include('includes/nav.inc');

if (isset($_SESSION['membername'])) { ?>
    <div class="container-fluid bg-light">
        <div class="row justify-content-center">
            <div class="col-lg-4 bg-light rounded px-4">
                <h4 class="text-center text-dark p-1">Upload Artwork</h4>
                <div class="form-group text-dark p-1">
                    <form action="upload_artwork_process.php" method="post" enctype="multipart/form-data">
                        <label class="required" for="title">Artwork Title</label>
                        <input class="form-control form-control-sm" type="text" name="title" id="title" required>
                        <label class="required" for="type">Type</label>
                        <input class="form-control form-control-sm" type="text" name="type" id="type" required>
                        <label for="year">Year</label>
                        <input class="form-control form-control-sm" type="number" name="year" id="year">
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input class="form-control form-control-sm" type="number" name="price" id="price">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control form-control-sm" rows="6" cols="39" name="description" id="description"></textarea>
                        </div>
                        <br>
                        <div class="form-group">
                            <input class="form-control p-1" type="file" name="artwork" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control btn btn-warning btn-block" type="submit" name="upload" value="Upload Artwork">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php
include('includes/footer.inc');
//header("Location:index.php");
?>