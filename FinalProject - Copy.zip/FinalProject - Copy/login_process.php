<?php
include("includes/db_connect.inc");

$sql = "SELECT * FROM member WHERE `membername`= ? and `password` = SHA(?)";
$membername = $_POST['membername'];
$password = $_POST['password'];

var_dump($_POST);

$stmt = $conn->prepare($sql);

$stmt->bind_param("ss", $membername, $password);

$stmt->execute();

$result = $stmt->get_result();

session_start();
if ($result->num_rows > 0) {
    $_SESSION['membername'] = $membername;
} else {
    $_SESSION['err'] = "User cannot be logged in!";
}
$conn->close();
//header("Location:index.php");
var_dump($_SESSION);
exit(0);
