<?php
include('includes/db_connect.inc');

function validate_input($str)
{
    $str = trim($str);
    $str = stripslashes($str);
    $str = htmlspecialchars($str);
    return $str;
}
$membername = validate_input($_POST['membername']);
$password = $_POST['password'];

$sql = "INSERT INTO member (`membername`, `password`, `reg_date`) VALUES (?, SHA(?), now())";

$stmt = $conn->prepare($sql);

$stmt->bind_param("ss", $membername, $password);

$stmt->execute();
//var_dump($stmt);
session_start();

if ($stmt->affected_rows > 0) {
    $_SESSION['usrmsg'] = "Successful registration. You can login now.";
} else {
    $_SESSION['err'] = "You have not registered yet";
}
//echo ($_SESSION['usrmsg']); 

$conn->close();
//back to home
header("Location:index.php");
exit(0);
